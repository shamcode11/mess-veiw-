# Mess_Management

This is Hackathon Project using MERN stack

This Project has Won 3rd Price in Hackathon.

To try it your self :

 you should have NodeJs installed, mongodb.

- git clone <https://github.com/Jenil45/Mess_Management.git>
- cd Mess_Management
- should do both in any manner

- | cd messmate | cd backend |
   | ---------- | ---------- |
   | npm i      |    npm i   |
   | npm start | nodemon index.js |

- create your own .env file by reffering .env.example file in backend folder

